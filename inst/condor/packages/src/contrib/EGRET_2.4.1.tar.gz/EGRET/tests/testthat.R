library(testthat)
library(EGRET)
test_check("EGRET")