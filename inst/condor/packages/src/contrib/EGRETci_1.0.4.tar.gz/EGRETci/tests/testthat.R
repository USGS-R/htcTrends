library(testthat)
library(EGRETci)
test_check("EGRETci")
