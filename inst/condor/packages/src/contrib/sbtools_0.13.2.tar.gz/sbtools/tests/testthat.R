library(testthat)
test_check('sbtools')