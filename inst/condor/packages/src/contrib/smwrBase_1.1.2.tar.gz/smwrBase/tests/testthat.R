library(testthat)
library(smwrBase)
test_check("smwrBase")