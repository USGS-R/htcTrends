library(smwrGraphs)

set.seed(3636)
X <- rnorm(32)
Y <- X + rnorm(32)

setGD()
# Step 1
AA.pl <- xyPlot(X, Y, Plot=list(what="none"))
# Step 2
addGrid(AA.pl)
AA.pl <- addXY(X, Y, Plot=list(what="points"))

# Box plot:
set.seed(27036)
BP <- rchisq(32, 3)
# Generate a small random sample
bp <- rchisq(4, 3)
# Create grouping variables
Gchar <- rep(c("A", "B"), 16)
Gnum <- rep(c(1998, 2002), 16)
AA.lo <- setLayout(width=rep(1.25, 4), height=4, xtop=1.5)
AA.gr <- setGraph(1, AA.lo)
boxPlot(BP, margin=AA.gr)
addTitle("Truncated")
setGraph(2, AA.lo)
boxPlot(BP, Box=list(type="simple"), margin=AA.gr)
addTitle("Simple")
setGraph(3, AA.lo)
boxPlot(BP, Box=list(type="tukey"), margin=AA.gr)
addTitle("Tukey")
setGraph(4, AA.lo)
boxPlot(BP, Box=list(type="extended"), margin=AA.gr)
addTitle("Extended")