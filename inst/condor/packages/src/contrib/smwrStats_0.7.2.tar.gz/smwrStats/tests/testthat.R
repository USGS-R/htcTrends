library(testthat)
library(smwrStats)
test_check("smwrStats")