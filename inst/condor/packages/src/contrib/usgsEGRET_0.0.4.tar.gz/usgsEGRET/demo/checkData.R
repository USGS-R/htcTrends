#Check raw data:
eList <- Choptank_eList

multiPlotDataOverview(eList)