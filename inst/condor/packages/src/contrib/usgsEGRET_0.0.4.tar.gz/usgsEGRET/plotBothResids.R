plotBothResids<-function(rrSample,xlim,ylim,xspace,yspace){
	
  localSample<-rrSample
	
  xTicks <- seq(xlim[1],xlim[2],xspace)
	
  yTicks <- seq(ylim[1],ylim[2],yspace)
	
  genericEGRETDotPlot(localSample$yHat,localSample$rResid,
                      xlim=xlim,ylim=ylim,
                      xTicks=xTicks,yTicks=yTicks,
                      printTitle=FALSE,pch=1,cex=0.9)
	
  par(new=TRUE)
	
  unSample<-subset(localSample,Uncen==1)
	
  genericEGRETDotPlot(unSample$yHat,unSample$rResid,
                      xlim=xlim,ylim=ylim,
                      xTicks=xTicks,yTicks=yTicks,
                      printTitle=FALSE,pch=16,cex=0.9)
	abline(h=0)
}