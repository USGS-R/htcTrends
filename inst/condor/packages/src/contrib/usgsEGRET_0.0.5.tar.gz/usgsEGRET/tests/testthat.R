library(testthat)
library(usgsEGRET)
test_check("usgsEGRET")