library(sbtools)
library(usgsEGRET)
source("D:/LADData/RCode/htcTrends/inst/condor/auth.R")
topFolderID <- "5679a0e9e4b0da412f4fc2b7" #Phase II

infoDataTotal <- readRDS("D:/LADData/RCode/htcTrends/inst/condor/infoData.rds")
sampleDataTotal <- readRDS("D:/LADData/RCode/htcTrends/inst/condor/sampleData.rds")
flowDataTotal <- readRDS("D:/LADData/RCode/htcTrends/inst/condor/flowData.rds")

tempFolder <- tempdir()
# runs that didn't work: 48,51,73,87,107,108,111,137,152,174,223,244,261
#152: minNumUncen is greater than total number of samples
bad <- c(48,51,73,87,107,108,111,137,152,174,223,244)
#didn't update sb starting at bad = 261
for(i in 2137:nrow(infoDataTotal)){
  flowSite <- infoDataTotal$Gage_number[i]
  sampleSite <- infoDataTotal$Site_no[i]
  parameter <- infoDataTotal$paramShortName[i]
  shortName <- infoDataTotal$Site_no[i]
  
  id <- paste(parameter, sampleSite,sep="_")
  x <- query_item_identifier(type='naqwa', scheme = 'dataII', key = id)
  possibleError <- tryCatch(
    fileStuff <- item_list_files(x$id),
           error = function(e) e
           )
  if(all(names(possibleError) %in% c("fname","size","url"))){
    item_file_download(x$id, names="eList.rds",
                       destinations = file.path(tempFolder,"eList.rds"), 
                       overwrite_file=TRUE)    
    
    eList <- readRDS(file.path(tempFolder,"eList.rds"))
    setPDF(layout = "landscape", basename = "fluxBiasMulti_GOOD")
    fluxBiasMulti(eList,USGSstyle = TRUE)
    graphics.off()
    
    item_append_files(x$id, "fluxBiasMulti_GOOD.pdf")
  } else {
    cat(i,"\n")
    bad <- c(bad,i)
  }
}

folderStuff <- item_list_children("5679a0e9e4b0da412f4fc2b7", limit = 5000)
folderStuff <- query_item_in_folder("5679a0e9e4b0da412f4fc2b7", limit = 5000)

newBad <- NA
for(i in bad[144:length(bad)]){
  id <- paste(infoDataTotal$paramShortName[i], infoDataTotal$Site_no[i],sep="_")
  key <- folderStuff$id[folderStuff$title == id]
  if(length(nchar(key)) > 0){
    x <- suppressMessages(item_update_identifier(id = key, type = 'naqwa', 
                                                 'dataII', id))   
    item_file_download(key, names="eList.rds",
                       destinations = file.path(tempFolder,"eList.rds"), 
                       overwrite_file=TRUE)    
    
    eList <- readRDS(file.path(tempFolder,"eList.rds"))
    setPDF(layout = "landscape", basename = "fluxBiasMulti_GOOD")
    fluxBiasMulti(eList,USGSstyle = TRUE)
    graphics.off()
    
    item_append_files(key, "fluxBiasMulti_GOOD.pdf")
  } else {
    newBad <- c(newBad, i)
    cat(i,"\n")
  }

}

newNewBad <- NA
for(i in newBad[-1:-57]){
  id <- paste(infoDataTotal$paramShortName[i], infoDataTotal$Site_no[i],sep="_")
  x <- query_item_in_folder(id, "5679a0e9e4b0da412f4fc2b7")
  key <- x$id
  if(length(nchar(key)) > 0){
    x <- suppressMessages(item_update_identifier(id = key, type = 'naqwa', 
                                                 'dataII', id))   
    item_file_download(key, names="eList.rds",
                       destinations = file.path(tempFolder,"eList.rds"), 
                       overwrite_file=TRUE)    
    
    eList <- readRDS(file.path(tempFolder,"eList.rds"))
    setPDF(layout = "landscape", basename = "fluxBiasMulti_GOOD")
    fluxBiasMulti(eList,USGSstyle = TRUE)
    graphics.off()
    
    item_append_files(key, "fluxBiasMulti_GOOD.pdf")
  } else {
    newNewBad <- c(newNewBad, i)
    cat(i,"\n")
  }
}

for(i in newNewBad[-1]){
  id <- paste(infoDataTotal$paramShortName[i], infoDataTotal$Site_no[i],sep="_")
  x <- query_item_in_folder(id, "5679a0e9e4b0da412f4fc2b7")
  
  
}
